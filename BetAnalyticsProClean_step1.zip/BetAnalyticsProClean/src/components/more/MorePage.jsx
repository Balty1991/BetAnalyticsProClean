import { useMemo, useState } from 'react';
import UnifiedPredictionEngine from './UnifiedPredictionEngine.jsx';
import VerdictPerformance from './VerdictPerformance.jsx';
import ClvTracker from './ClvTracker.jsx';
import Ml5Analysis from './Ml5Analysis.jsx';
import MatchesHistory from './MatchesHistory.jsx';

const MORE_SECTIONS = [
  { key: 'unified', label: '🎯 Motor de Predicții Unificat' },
  { key: 'verdict', label: '📊 Performanță Verdict' },
  { key: 'clv', label: '📈 CLV Tracker' },
  { key: 'ml5', label: '🔬 Analiză ML5' },
  { key: 'history', label: '📚 Istoric Meciuri' }
];

export default function MorePage({ loading, matches, rawData }) {
  const [section, setSection] = useState('history');

  const content = useMemo(() => {
    if (loading) return <div className="panel state-panel">Se încarcă datele...</div>;
    if (section === 'unified') return <UnifiedPredictionEngine data={rawData?.proIntelligence} />;
    if (section === 'verdict') return <VerdictPerformance data={rawData?.predictionTypeHistory} quality={rawData?.modelQuality} />;
    if (section === 'clv') return <ClvTracker data={rawData?.clvTracker} />;
    if (section === 'ml5') return <Ml5Analysis data={rawData?.modelQuality} benchmarks={rawData?.modelBenchmarks} insights={rawData?.trainingInsights} />;
    return <MatchesHistory matches={matches} recommendationLog={rawData?.recommendationLog || []} />;
  }, [loading, matches, rawData, section]);

  return (
    <section className="more-page">
      <div className="page-head">
        <div>
          <div className="section-kicker">Mai mult</div>
          <h1>Module avansate</h1>
          <p className="muted">Secțiunile mutate în zona avansată, fără să încarce Dashboard-ul.</p>
        </div>
      </div>

      <div className="more-tabs">
        {MORE_SECTIONS.map((item) => (
          <button key={item.key} className={`more-tab ${section === item.key ? 'active' : ''}`} onClick={() => setSection(item.key)}>
            {item.label}
          </button>
        ))}
      </div>

      {content}
    </section>
  );
}
