import { DEFAULT_FILTERS, getLeagues } from '../../logic/matchFilters.js';

export default function MatchFilters({ matches, filters, onChange, onReset }) {
  const leagues = getLeagues(matches);

  function patch(key, value) {
    onChange({ ...filters, [key]: value });
  }

  const isDirty = JSON.stringify(filters) !== JSON.stringify(DEFAULT_FILTERS);

  return (
    <div className="match-filters panel">
      <label>
        <span>Caută</span>
        <input value={filters.search} onChange={(e) => patch('search', e.target.value)} placeholder="echipă, ligă, piață" />
      </label>

      <label>
        <span>Ligă</span>
        <select value={filters.league} onChange={(e) => patch('league', e.target.value)}>
          <option value="all">Toate ligile</option>
          {leagues.map((league) => <option key={league} value={league}>{league}</option>)}
        </select>
      </label>

      <label>
        <span>Probabilitate minimă</span>
        <select value={filters.minProbability} onChange={(e) => patch('minProbability', Number(e.target.value))}>
          <option value="0">Orice</option>
          <option value="60">60%+</option>
          <option value="70">70%+</option>
          <option value="80">80%+</option>
        </select>
      </label>

      <label>
        <span>Edge minim</span>
        <select value={filters.minEdge} onChange={(e) => patch('minEdge', Number(e.target.value))}>
          <option value="0">Orice</option>
          <option value="3">3pp+</option>
          <option value="5">5pp+</option>
          <option value="10">10pp+</option>
        </select>
      </label>

      <label>
        <span>Sortare</span>
        <select value={filters.sort} onChange={(e) => patch('sort', e.target.value)}>
          <option value="date">Dată</option>
          <option value="score">Scor</option>
          <option value="probability">Probabilitate</option>
          <option value="edge">Edge</option>
          <option value="odds">Cotă</option>
        </select>
      </label>

      <button type="button" className="btn reset-btn" onClick={onReset} disabled={!isDirty}>
        Resetează filtrele
      </button>
    </div>
  );
}
