import { fmtDateTime, fmtOdd, fmtPct, fmtSigned } from '../../logic/format.js';

function categoryBadges(match) {
  const flags = match.categoryFlags || {};
  const badges = [];
  if (flags.top) badges.push('⭐ Top');
  if (flags.over15) badges.push('🔥 O1.5');
  if (flags.btts) badges.push('🤝 BTTS');
  if (flags.under35) badges.push('🧊 U3.5');
  if (flags.value) badges.push('💰 Value');
  return badges;
}

export default function MatchCard({ match }) {
  const bet = match.bestBet || {};
  const badges = categoryBadges(match);

  return (
    <article className="match-card panel">
      <div className="match-card-top">
        <div>
          <div className="league-line">{match.league}</div>
          <h2>{match.home} <span>vs</span> {match.away}</h2>
        </div>
        <div className="score-box">
          <strong>{Math.round(match.smartScore || 0)}</strong>
          <span>score</span>
        </div>
      </div>

      <div className="match-meta">
        <span>{fmtDateTime(match.date)}</span>
        <span>xG {match.xgTotal.toFixed(2)}</span>
        {match.mostLikelyScore ? <span>scor probabil {match.mostLikelyScore}</span> : null}
      </div>

      <div className="badges-row">
        {badges.map((badge) => <span key={badge} className="badge">{badge}</span>)}
      </div>

      <div className="main-pick">
        <div>
          <span className="muted tiny">Piață recomandată</span>
          <strong>{bet.label || '—'}</strong>
        </div>
        <div>
          <span className="muted tiny">Prob.</span>
          <strong>{fmtPct(bet.probability || 0)}</strong>
        </div>
        <div>
          <span className="muted tiny">Cotă</span>
          <strong>{fmtOdd(bet.odds)}</strong>
        </div>
        <div>
          <span className="muted tiny">EV</span>
          <strong className={(bet.evPct || 0) >= 0 ? 'positive' : 'negative'}>{fmtSigned(bet.evPct || 0, '%')}</strong>
        </div>
      </div>

      <div className="market-grid">
        <div><span>O1.5</span><strong>{fmtPct(match.probOver15)}</strong></div>
        <div><span>BTTS</span><strong>{fmtPct(match.probBtts)}</strong></div>
        <div><span>U3.5</span><strong>{fmtPct(match.probUnder35)}</strong></div>
        <div><span>Edge</span><strong>{fmtSigned(bet.edgePct || 0, 'pp')}</strong></div>
      </div>

      {bet.reasons?.length ? (
        <p className="reason-line">{bet.reasons.join(' · ')}</p>
      ) : null}
    </article>
  );
}
