import { MATCH_CATEGORIES } from '../../logic/matchCriteria.js';

export default function MatchCategoryTabs({ active, onChange, counts }) {
  return (
    <div className="match-category-tabs" role="tablist" aria-label="Categorii meciuri">
      {MATCH_CATEGORIES.map((category) => (
        <button
          key={category.key}
          type="button"
          className={`match-category-tab ${active === category.key ? 'active' : ''}`}
          onClick={() => onChange(category.key)}
        >
          <span>{category.label}</span>
          <strong>{counts?.[category.key] || 0}</strong>
        </button>
      ))}
    </div>
  );
}
