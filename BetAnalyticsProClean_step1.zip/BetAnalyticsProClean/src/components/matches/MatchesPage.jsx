import { useMemo, useState } from 'react';
import MatchCategoryTabs from './MatchCategoryTabs.jsx';
import MatchFilters from './MatchFilters.jsx';
import MatchList from './MatchList.jsx';
import EmptyState from './EmptyState.jsx';
import { DEFAULT_FILTERS, applyMatchFilters } from '../../logic/matchFilters.js';
import { getCategoryCounts, getMatchesForCategory } from '../../logic/matchCriteria.js';

export default function MatchesPage({ loading, matches }) {
  const [category, setCategory] = useState('all');
  const [filters, setFilters] = useState(DEFAULT_FILTERS);

  const counts = useMemo(() => getCategoryCounts(matches), [matches]);
  const categoryMatches = useMemo(() => getMatchesForCategory(matches, category), [matches, category]);
  const visibleMatches = useMemo(() => applyMatchFilters(categoryMatches, filters), [categoryMatches, filters]);

  function resetFilters() {
    setFilters(DEFAULT_FILTERS);
    setCategory('all');
  }

  return (
    <section className="matches-page">
      <div className="page-head">
        <div>
          <div className="section-kicker">Meciuri</div>
          <h1>Selecții pe criteriile motorului</h1>
          <p className="muted">Rubricile sunt calculate din aceleași piețe principale: O1.5, BTTS, U3.5 și Value.</p>
        </div>
        <div className="count-card">
          <strong>{loading ? '—' : visibleMatches.length}</strong>
          <span>afișate</span>
        </div>
      </div>

      <MatchCategoryTabs active={category} onChange={setCategory} counts={counts} />
      <MatchFilters matches={categoryMatches} filters={filters} onChange={setFilters} onReset={resetFilters} />

      {loading ? <div className="panel state-panel">Se încarcă datele...</div> : null}
      {!loading && visibleMatches.length === 0 ? <EmptyState onReset={resetFilters} /> : null}
      {!loading && visibleMatches.length > 0 ? <MatchList matches={visibleMatches} /> : null}
    </section>
  );
}
