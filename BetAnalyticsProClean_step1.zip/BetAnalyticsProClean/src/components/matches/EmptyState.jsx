export default function EmptyState({ onReset }) {
  return (
    <div className="panel empty-state">
      <h2>Niciun meci găsit pentru selecția curentă.</h2>
      <p className="muted">Schimbă categoria sau curăță filtrele.</p>
      <button type="button" className="btn primary" onClick={onReset}>Resetează filtrele</button>
    </div>
  );
}
